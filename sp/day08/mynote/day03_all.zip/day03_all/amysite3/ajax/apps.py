from django.apps import AppConfig


class AjaxConfig(AppConfig):
    name = 'ajax'
